
export const BASE_URL = "https://quronhusnixati.uz";
export const FILE_URL = "https://quronhusnixati.uz/static/";
